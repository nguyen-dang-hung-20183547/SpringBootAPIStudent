package com.example.demo.model;

public interface StudentValidator {
    public boolean isValid(Student s);
    public boolean isValid(StudentCreateModel s);
}
