package com.example.demo.config;

import javax.sql.DataSource;

public interface DataSourceConfig {
    public DataSource getDataSource();
}
